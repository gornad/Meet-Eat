﻿using System;
using Xamarin.Forms;

namespace MyShop
{
    public class HomeViewModel : ViewModelBase
    {
        public HomeViewModel(Page page) : base(page)
        {
            Title = "My Shoppe";
        }


    }
}

