﻿using System;
using Xamarin.Forms;

namespace Sport.Mobile.Shared
{
	public class ThemedNavigationPage : NavigationPage
	{
		public ThemedNavigationPage()
		{
		}

		public ThemedNavigationPage(ContentPage root) : base(root)
		{
		}
	}
}

