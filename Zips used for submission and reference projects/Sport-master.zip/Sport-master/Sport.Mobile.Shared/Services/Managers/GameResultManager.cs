﻿
namespace Sport.Mobile.Shared
{
	public class GameResultManager : BaseManager<GameResult>
	{
		public override string Identifier => "GameResult";
	}
}