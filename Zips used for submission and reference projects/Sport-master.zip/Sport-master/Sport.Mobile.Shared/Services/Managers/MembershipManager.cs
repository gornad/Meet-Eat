﻿
namespace Sport.Mobile.Shared
{
	public class MembershipManager : BaseManager<Membership>
	{
		public override string Identifier => "Membership";
	}
}