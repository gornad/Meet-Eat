﻿
namespace Sport.Service
{
	internal class Constants
	{
		internal static readonly string HubConnectionString = "Endpoint=sb://xamarinsporthubnamespace.servicebus.windows.net/;SharedAccessKeyName=DefaultFullSharedAccessSignature;SharedAccessKey=TF6GC3POPu3WnxZxKdv520ITMZ3rh7Lmj58STHpMuow=";
		internal static readonly string HubName = "XamarinSportNotificationHub";
	}
}
