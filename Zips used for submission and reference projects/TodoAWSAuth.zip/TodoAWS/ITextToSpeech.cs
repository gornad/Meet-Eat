﻿using System;

namespace TodoAWSSimpleDB
{
	public interface ITextToSpeech
	{
		void Speak (string text);
	}
}
