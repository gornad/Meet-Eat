using System;
using UIKit;

namespace Acquaint.Native.iOS
{
	public partial class MainViewController : UIViewController
	{
		public MainViewController (IntPtr handle) : base (handle)
		{
		}
	}
}
