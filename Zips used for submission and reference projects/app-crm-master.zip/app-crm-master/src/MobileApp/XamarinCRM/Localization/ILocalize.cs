﻿

using System.Globalization;

namespace XamarinCRM.Localization
{
    public interface ILocalize
    {
        CultureInfo GetCurrentCultureInfo();
    }
}

