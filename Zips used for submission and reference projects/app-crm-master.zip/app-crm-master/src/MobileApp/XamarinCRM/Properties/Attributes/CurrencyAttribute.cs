﻿
using System;

namespace XamarinCRM.Properties.Attributes
{
    public class CurrencyAttribute : Attribute { }
}

